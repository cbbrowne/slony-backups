This is Version 1.2.12 Release
And, Change of the acquisition method of share path.

As for make,This is PostgreSQL version 8.1.10
Please install before this.

Regards,
Hiroshi Saito