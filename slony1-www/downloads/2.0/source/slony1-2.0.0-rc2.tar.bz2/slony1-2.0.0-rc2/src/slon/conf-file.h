/* $Id: conf-file.h,v 1.2 2005-01-12 17:27:10 darcyb Exp $ */
#ifndef __CONF_FILE_H__
#define __CONF_FILE_H__

void		ProcessConfigFile(const char *filename);

#endif
