-- There Is No table "snobol"
alter table snobol add column id integer not null unique;