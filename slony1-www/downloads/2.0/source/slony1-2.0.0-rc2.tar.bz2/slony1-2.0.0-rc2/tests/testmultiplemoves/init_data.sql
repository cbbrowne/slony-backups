INSERT INTO table1(data) VALUES ('placeholder a');
INSERT INTO table1(data) VALUES ('placeholder b');
INSERT INTO table1a(table1_id,data) VALUES (1,'placeholder a');
INSERT INTO table1a(table1_id,data) VALUES (2,'placeholder b');

INSERT INTO table2(data) VALUES ('placeholder a');
INSERT INTO table2(data) VALUES ('placeholder b');
INSERT INTO table2a(table2_id,data) VALUES (1,'placeholder a');
INSERT INTO table2a(table2_id,data) VALUES (2,'placeholder b');

