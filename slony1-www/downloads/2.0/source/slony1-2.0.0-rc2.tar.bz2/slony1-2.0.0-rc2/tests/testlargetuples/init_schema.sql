CREATE TABLE table1(
  id		SERIAL		PRIMARY KEY, 
  data		TEXT
);
