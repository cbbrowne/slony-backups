INSERT INTO table1(data) VALUES ('placeholder 1');
INSERT INTO table2(table1_id,data) VALUES (1,'placeholder 1');
INSERT INTO table3(table2_id) VALUES (1);
